package assignment5;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.lang.*;
import java.awt.*;
import java.util.List;

public class TwoDimRaggedArrayUtility {
	static double getAverage(double[][] data) {

		return 2.5;
	}

	static double getColumnTotal(double[][] data, int col) {
		return col;
	}

	static double getHighestInArray(double[][] data) {
		return 0;
	}

	static double getHighestInColumn(double[][] data, int col) {
		return 0;
	}

	static double getHighestInRow(double[][] data, int row) {
		return 0;
	}

	static double getLowestInArray(double[][] data) {
		return 0;
	}

	static double getLowestInColumn(double[][] data, int col) {
		return 0;
	}

	static double getLowestInRow(double[][] data, int row) {
		return 0;
	}

	static double getRowTotal(double[][] data, int row) {
		return 0;
	}

	static double[][] readFile(java.io.File file) throws FileNotFoundException {
//		final int SIZE = 10;
//		double[][] data = new double [SIZE][SIZE] ;
//		String[][] array = new String[SIZE][SIZE];
//		//array = null;
//		//int i = 0;
//		int row = 0;
//		String line;
//		Scanner in;
//		try {
//			in = new Scanner(file);
//			
//			//----------------------------------
//			//is there more data to read in file
//			while (in.hasNextLine()){ 
//			    line = in.nextLine(); // reads in entire line
//			    if (line.isEmpty()) // if blank line
//			        continue; // skip over blank line (end of loop)
//			    // do whatever processing at the end of each line
//
//			    array [row] = line.split("\\s"); // split line into individual strings (numbers)
//			   // String[] tokens = line.split("\\s");
//			    for(int j = 0; j< array[row].length; j++){
//
//			    	System.out.println( "array [" + row + "][" + j + "] " + array[row][j]);
//
//			    }
//			    // get next token from 1253.65 4566.50 2154.36 7532.45 3388.44 6598.23
//			    for (String token : array[row]) { // for each string number
//			        if (token.isEmpty())
//			            continue;
//			        // do whatever processing for each token
//			        //here covert the array to double 
//			        
//			    }
//			    row++;
//			}
//			System.out.println("end of array");
//
//			
//			for (int i = 0; i < array.length; i++){
//				System.out.println("start of for loop"+ i);
//
//			
//				for (int j = 0; j < array[i].length; j++){
//					
//					if (!(array[i] == null)){
//						System.out.println(j);
//						data[i][j] = Double.parseDouble(array[i][j]);
//					}
//					else{
//						System.out.print("end");
//						break;
//					}
//
//				}
//			}
//			//----------------------------------
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		String [][] array = null;
		double[][] data = null;
		Scanner in = new Scanner (file);
		Scanner line;
		int row, col = 0;
		
		if(in.hasNextLine()){
			array = new String [10][10];
			//initilise the array to nulls
			for(row = 0 ; row<10; row++)
				for(col = 0; col < 10; col ++)
					array[row][col] = null;
			row = 0;
			while (in.hasNextLine()){
				line = new Scanner(in.nextLine());
				col = 0;
				while (line.hasNextDouble()){
					array[row][col++]= Double.toString(line.nextDouble());
				}
			row ++;
			line.close();
			}
		//in.close();

		//convert to rag array
		row = 0;
		while(array[row][0] != null)
			row++;
		data = new double[row][];
		//fill each column for each row
		for(row = 0; row < data.length; row ++){
			col = 0;
			//find num of col for each row
			while(array[row][col] != null)
				col++;
			data[row] = new double[col];
			for(int index = 0; index < array[row].length; index++)
				data[row][index]= Double.parseDouble(array[row][index]);
		}
	}
		in.close();
		
		return data;
	}

	static void writeToFile(double[][] data, java.io.File outputFile) throws FileNotFoundException {

		int row,col;
		PrintWriter outF = new PrintWriter(outputFile);
		
		for(row = 0; row < data.length; row++){
			for (col =0; col < data[row].length-1; col++)
				outF.println(data[row][col]);
		}
	}

	static double getTotal(double[][] dataSet2) {
		return 0;
	}

}
